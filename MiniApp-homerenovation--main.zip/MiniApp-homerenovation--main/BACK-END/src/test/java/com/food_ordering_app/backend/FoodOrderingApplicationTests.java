package com.food_ordering_app.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
