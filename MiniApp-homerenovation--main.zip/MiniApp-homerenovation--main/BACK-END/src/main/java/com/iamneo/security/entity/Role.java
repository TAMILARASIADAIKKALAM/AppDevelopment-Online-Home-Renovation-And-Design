package com.iamneo.security.entity;

public enum Role {
    USER,
    ADMIN
}
